## Test environments
* local OS X install, R 3.3.1
* ubuntu 12.04 (on travis-ci), R 3.3.1
* ubuntu 14.04 (local), r-devel
* win-builder (devel and release)
* local, aged 32-bit Windows 10 R 3.3.1

## R CMD check results

0 errors | 0 warnings | 1 note

* This is a new release.

