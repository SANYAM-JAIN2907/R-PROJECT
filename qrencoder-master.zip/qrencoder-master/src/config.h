#define VERSION "3.9.0"
#define PACKAGE_NAME "QRencode"
#define PACKAGE_TARNAME "qrencode"
#define PACKAGE_VERSION "3.9.0"
#define PACKAGE_STRING "QRencode 3.9.0"
#define PACKAGE_BUGREPORT ""
#define PACKAGE_URL ""
#define MAJOR_VERSION 3
#define MINOR_VERSION 9
#define MICRO_VERSION 0
