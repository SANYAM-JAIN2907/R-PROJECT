library(testthat)
library(qrencoder)

test_check("qrencoder")
